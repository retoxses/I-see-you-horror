package com.granyo.iseeyou.client;

import com.granyo.iseeyou.ModEntityTypes;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelLayerRegistry;
import net.minecraft.resources.Identifier;

public final class ISeeYouClient implements ClientModInitializer {
    public static final ModelLayerLocation MODEL_LAYER = new ModelLayerLocation(
            Identifier.fromNamespaceAndPath("iseeyou_horror", "i_see_you"), "main");

    @Override
    public void onInitializeClient() {
        ModelLayerRegistry.registerModelLayer(MODEL_LAYER, ISeeYouModel::createBodyLayer);
        EntityRendererRegistry.register(ModEntityTypes.I_SEE_YOU, ISeeYouRenderer::new);
    }
}
