package com.granyo.iseeyou;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class ModSounds {
    public static final SoundEvent WHISPER = register("whisper");
    public static final SoundEvent RUSH = register("rush");
    public static final SoundEvent VANISH = register("vanish");

    private static SoundEvent register(String path) {
        Identifier id = Identifier.fromNamespaceAndPath("iseeyou_horror", path);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void initialize() {}
    private ModSounds() {}
}
