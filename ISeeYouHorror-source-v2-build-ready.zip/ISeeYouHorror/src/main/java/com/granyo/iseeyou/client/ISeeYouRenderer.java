package com.granyo.iseeyou.client;

import com.granyo.iseeyou.ISeeYouEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public final class ISeeYouRenderer extends MobRenderer<ISeeYouEntity, ISeeYouRenderState, ISeeYouModel> {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(
            "iseeyou_horror", "textures/entity/i_see_you.png");

    public ISeeYouRenderer(EntityRendererProvider.Context context) {
        super(context, new ISeeYouModel(context.bakeLayer(ISeeYouClient.MODEL_LAYER)), 1.5F);
    }

    @Override
    public ISeeYouRenderState createRenderState() {
        return new ISeeYouRenderState();
    }

    @Override
    public Identifier getTextureLocation(ISeeYouRenderState state) {
        return TEXTURE;
    }
}
