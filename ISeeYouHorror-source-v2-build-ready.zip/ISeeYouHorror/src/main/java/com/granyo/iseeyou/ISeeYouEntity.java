package com.granyo.iseeyou;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.EnderMan;
import net.minecraft.world.level.Level;

/** Custom entity type using Enderman pathfinding, with a separate model and large hitbox. */
public final class ISeeYouEntity extends EnderMan {
    public ISeeYouEntity(EntityType<? extends EnderMan> type, Level level) {
        super(type, level);
    }
}
