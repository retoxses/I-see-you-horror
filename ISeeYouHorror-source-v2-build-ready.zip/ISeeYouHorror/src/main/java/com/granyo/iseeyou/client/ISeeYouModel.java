package com.granyo.iseeyou.client;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.PartPose;
import net.minecraft.util.Mth;

public final class ISeeYouModel extends EntityModel<ISeeYouRenderState> {
    private final ModelPart head;
    private final ModelPart body;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public ISeeYouModel(ModelPart root) {
        super(root);
        head = root.getChild("head");
        body = root.getChild("body");
        leftArm = root.getChild("left_arm");
        rightArm = root.getChild("right_arm");
        leftLeg = root.getChild("left_leg");
        rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-7, -120, -6, 14, 16, 12)
                .texOffs(0, 32).addBox(-5, -116, -7, 3, 2, 1)
                .texOffs(0, 32).addBox(2, -116, -7, 3, 2, 1), PartPose.ZERO);
        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(32, 0).addBox(-6, -104, -4, 12, 56, 8), PartPose.ZERO);
        root.addOrReplaceChild("left_arm", CubeListBuilder.create()
                .texOffs(56, 0).addBox(-2, -102, -3, 4, 64, 4), PartPose.offset(-9, 0, 0));
        root.addOrReplaceChild("right_arm", CubeListBuilder.create()
                .texOffs(72, 0).addBox(-2, -102, -3, 4, 64, 4), PartPose.offset(9, 0, 0));
        root.addOrReplaceChild("left_leg", CubeListBuilder.create()
                .texOffs(88, 0).addBox(-2, -48, -3, 4, 72, 5), PartPose.offset(-3, 0, 0));
        root.addOrReplaceChild("right_leg", CubeListBuilder.create()
                .texOffs(104, 0).addBox(-2, -48, -3, 4, 72, 5), PartPose.offset(3, 0, 0));
        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public void setupAnim(ISeeYouRenderState state) {
        super.setupAnim(state);
        float speed = state.walkAnimationSpeed;
        boolean running = speed > 0.55F;
        float swing = state.walkAnimationPos * (running ? 0.48F : 0.22F);
        float amount = Mth.clamp(speed * (running ? 1.8F : 1.0F), 0.0F, 1.6F);
        float legSwing = running ? 0.95F : 0.52F;
        float armSwing = running ? 1.25F : 0.28F;
        leftLeg.xRot = Mth.cos(swing + Mth.PI) * legSwing * amount;
        rightLeg.xRot = Mth.cos(swing) * legSwing * amount;
        leftArm.xRot = Mth.cos(swing) * armSwing * amount - (running ? 0.35F : 0.08F);
        rightArm.xRot = Mth.cos(swing + Mth.PI) * armSwing * amount - (running ? 0.35F : 0.08F);
        leftArm.zRot = running ? 0.18F : 0.05F;
        rightArm.zRot = running ? -0.18F : -0.05F;
        body.xRot = running ? 0.16F : Mth.sin(state.ageInTicks * 0.055F) * 0.025F;
        head.yRot = state.yRot * Mth.DEG_TO_RAD + Mth.sin(state.ageInTicks * 0.075F) * 0.09F;
        head.xRot = state.xRot * Mth.DEG_TO_RAD + (running ? -0.12F : 0.0F);
    }
}
