package com.granyo.iseeyou;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ISeeYouHorror implements ModInitializer {
    private static final Map<UUID, Integer> PLAYER_COOLDOWNS = new HashMap<>();
    private static final Map<UUID, UUID> STALKERS = new HashMap<>();
    private static final Map<UUID, Integer> CHAT_TIMERS = new HashMap<>();
    private static final String[] WHISPERS = {
            "I SEE YOU.", "DON'T TURN AROUND.", "WHY ARE YOU RUNNING?",
            "I WAS HERE BEFORE YOU.", "LOOK BEHIND YOU.", "YOU HEARD THAT, RIGHT?",
            "...STAY STILL...", "I'M CLOSER THAN YOU THINK."
    };

    @Override
    public void onInitialize() {
        ModEntityTypes.initialize();
        ModSounds.initialize();
        ServerTickEvents.END_WORLD_TICK.register(ISeeYouHorror::onWorldTick);
    }

    private static void onWorldTick(ServerLevel world) {
        long dayTime = Math.floorMod(world.getDayTime(), 24000L);
        boolean night = dayTime >= 13000L && dayTime <= 23000L;

        for (ServerPlayer player : world.players()) {
            UUID playerId = player.getUUID();
            int cooldown = PLAYER_COOLDOWNS.getOrDefault(playerId, 0);
            if (cooldown > 0) PLAYER_COOLDOWNS.put(playerId, cooldown - 1);

            UUID stalkerId = STALKERS.get(playerId);
            Entity current = stalkerId == null ? null : world.getEntity(stalkerId);
            if (current != null && current.isAlive()) {
                int chatTimer = CHAT_TIMERS.getOrDefault(playerId, 20 * (7 + world.random.nextInt(8)));
                if (chatTimer <= 0) {
                    player.sendSystemMessage(Component.literal("§8[ ISeeYou ] §f" + WHISPERS[world.random.nextInt(WHISPERS.length)]));
                    CHAT_TIMERS.put(playerId, 20 * (9 + world.random.nextInt(13)));
                    if (world.random.nextInt(3) == 0) {
                        world.playSound(null, player.blockPosition(), ModSounds.WHISPER, SoundSource.HOSTILE, 0.8F, 0.75F + world.random.nextFloat() * 0.25F);
                    }
                } else {
                    CHAT_TIMERS.put(playerId, chatTimer - 1);
                }

                double distance = current.distanceToSqr(player);
                if (distance < 9.0 && world.random.nextInt(80) == 0) {
                    world.playSound(null, current.blockPosition(), ModSounds.RUSH, SoundSource.HOSTILE, 1.0F, 0.7F);
                }
                if (current.tickCount > 20 * 32 || !night && current.tickCount > 20 * 8) {
                    vanish(world, current);
                    STALKERS.remove(playerId);
                    CHAT_TIMERS.remove(playerId);
                    PLAYER_COOLDOWNS.put(playerId, 20 * (55 + world.random.nextInt(65)));
                }
                continue;
            } else if (stalkerId != null) {
                STALKERS.remove(playerId);
                CHAT_TIMERS.remove(playerId);
            }

            if (cooldown > 0 || !night || player.isSpectator() || player.isCreative() || world.random.nextInt(2200) != 0) {
                continue;
            }
            spawnWatcher(world, player);
        }
    }

    private static void spawnWatcher(ServerLevel world, ServerPlayer player) {
        double yaw = Math.toRadians(player.getYRot());
        boolean closeBehind = world.random.nextFloat() < 0.38F;
        double distance = closeBehind ? 5.0 + world.random.nextInt(3) : 17.0 + world.random.nextInt(12);
        double xOffset;
        double zOffset;
        if (closeBehind) {
            xOffset = Math.sin(yaw) * distance;
            zOffset = -Math.cos(yaw) * distance;
        } else {
            double angle = world.random.nextDouble() * Math.PI * 2.0;
            xOffset = Math.cos(angle) * distance;
            zOffset = Math.sin(angle) * distance;
        }
        int x = (int) Math.floor(player.getX() + xOffset);
        int z = (int) Math.floor(player.getZ() + zOffset);
        BlockPos surface = world.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                new BlockPos(x, world.getMaxY() - 1, z));

        ISeeYouEntity watcher = ModEntityTypes.I_SEE_YOU.create(world, EntitySpawnReason.EVENT);
        if (watcher == null) return;
        watcher.moveTo(surface.getX() + 0.5, surface.getY(), surface.getZ() + 0.5,
                world.random.nextFloat() * 360.0F, 0.0F);
        watcher.setCustomName(Component.literal("ISeeYou"));
        watcher.setCustomNameVisible(false);
        watcher.setTarget(player);
        watcher.setPersistenceRequired();

        if (world.addFreshEntity(watcher)) {
            STALKERS.put(player.getUUID(), watcher.getUUID());
            PLAYER_COOLDOWNS.put(player.getUUID(), 20 * 30);
            CHAT_TIMERS.put(player.getUUID(), 20 * (5 + world.random.nextInt(7)));
            if (closeBehind) {
                player.sendSystemMessage(Component.literal("§8[ ISeeYou ] §f...I'M RIGHT HERE."));
                world.playSound(null, player.blockPosition(), ModSounds.WHISPER, SoundSource.HOSTILE, 1.0F, 0.65F);
            } else {
                player.sendSystemMessage(Component.literal("§8[ ISeeYou ] §7Something is watching you..."));
                world.playSound(null, player.blockPosition(), ModSounds.WHISPER, SoundSource.HOSTILE, 0.75F, 0.8F);
            }
        }
    }

    private static void vanish(ServerLevel world, Entity watcher) {
        BlockPos pos = watcher.blockPosition();
        world.playSound(null, pos, ModSounds.VANISH, SoundSource.HOSTILE, 1.0F, 0.65F);
        watcher.discard();
    }
}
