package com.granyo.iseeyou;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.Registry;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntityTypes {
    public static final ResourceKey<EntityType<?>> I_SEE_YOU_KEY = ResourceKey.create(
            Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath("iseeyou_horror", "i_see_you"));

    public static final EntityType<ISeeYouEntity> I_SEE_YOU = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            I_SEE_YOU_KEY,
            EntityType.Builder.<ISeeYouEntity>of(ISeeYouEntity::new, MobCategory.MONSTER)
                    .sized(1.6F, 8.0F)
                    .clientTrackingRange(10)
                    .build(I_SEE_YOU_KEY)
    );

    private ModEntityTypes() {}

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(I_SEE_YOU, ISeeYouEntity.createAttributes());
    }
}
