package com.granyo.iseeyou.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public final class ISeeYouRenderState extends LivingEntityRenderState {
}
